
'use client'

import Quiz from "@/pages/page";
export default function Home() {


  return (
    <div>
      
      <Quiz/>

     
    </div>
  );
}
